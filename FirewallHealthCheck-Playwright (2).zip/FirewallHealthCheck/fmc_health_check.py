"""
Firewall Health Check - browser based (Playwright).

Opens the Cisco Secure Firewall Management Center in Edge/Chrome, logs in and
walks the same pages the engineer checks by hand:
  1. Overview > Dashboards > Summary Dashboard, Status tab (appliance status)
  2. System > Health > Monitor, then every unit in the tree
     (health status, HA role, CPU, memory, disk and critical partitions)
  3. Analysis > Intrusions > Events and Analysis > Connections > Events
Then it writes the report (HTML, CSV, screenshots) and emails it.

Read only: it only opens pages and reads them. Nothing is clicked that changes
anything on the FMC or the firewalls.

    python fmc_health_check.py --settings config/firewall.settings.json
    python fmc_health_check.py --settings ... --show      (watch the browser)
    python fmc_health_check.py --settings ... --no-email

Password: FMC_PASSWORD environment variable (GitLab CI/CD variable),
otherwise it asks. Exit code 0 = PASS, 2 = WARNING, 1 = FAIL or error.
"""

import argparse
import csv
import datetime as dt
import getpass
import html
import json
import os
import re
import smtplib
import sys
import time
from email.message import EmailMessage
from pathlib import Path

RANK = {"PASS": 0, "WARNING": 1, "FAIL": 2}
STATUS_WORDS = r"Critical|Warning|Normal|Disabled|Recovered|Unknown|Error"
DEFAULT_PAGES = {
    "login": "/ui/login",
    "dashboard": "",  # "" = the page FMC opens after login (Summary Dashboard)
    "health": "/ui/device-monitoring/health",
    "intrusions": "/events/index.cgi",
    "connections": "/events/index.cgi?table=rna_flow_stats",
}


def log(msg=""):
    print(msg, flush=True)


# ----------------------------------------------------------------- settings

def read_settings(path):
    s = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    s.setdefault("protocol", "https")
    s.setdefault("browser", "msedge")
    s.setdefault("show_browser", False)
    s.setdefault("units", [])
    s.setdefault("fmc_unit_name", "Firewall Management Center")
    s.setdefault("ha_pairs", {})
    s.setdefault("ha_expected_active", {})
    s.setdefault("cpu_warn_percent", 50)
    s.setdefault("memory_warn_percent", 50)
    s.setdefault("disk_warn_percent", 80)
    s.setdefault("disk_fail_percent", 90)
    s.setdefault("ignore_alerts", [])
    s.setdefault("check_events", True)
    s.setdefault("time_range", "Last 24 hours")
    s.setdefault("settle_seconds", 6)
    s.setdefault("page_timeout_seconds", 60)
    s.setdefault("assigned_to", "Contractor")
    s.setdefault("email", {})
    s["pages"] = {**DEFAULT_PAGES, **s.get("pages", {})}
    for key in ("fmc", "username"):
        if not s.get(key) or "CHANGE-ME" in str(s[key]):
            raise SystemExit(f"ERROR: fill in \"{key}\" in {path}")
    return s


# ----------------------------------------------------------------- results

class Row:
    def __init__(self, unit, kind):
        self.unit, self.kind = unit, kind
        self.result = "PASS"
        self.health = self.role = self.cpu = self.memory = self.disk = ""
        self.findings, self.notes = [], []

    def add(self, level, text):
        self.findings.append(f"{level}: {text}")
        if RANK[level] > RANK[self.result]:
            self.result = level


def is_ignored(text, ignore):
    return any(p.lower() in text.lower() for p in ignore if p)


def pct(text):
    return float(text.replace(",", ""))


# ----------------------------------------------------------------- page reading

def section(text, start, ends):
    """Text of one widget, from its heading to the next heading. The heading
    word also appears in tab bars, so the first part that holds data wins."""
    for m in re.finditer(rf"(?im)^\s*{start}\b.*$", text):
        rest = text[m.start():]
        head = len(m.group(0))
        stop = len(rest)
        for e in ends:
            m2 = re.search(rf"(?im)^\s*{e}\b", rest[head:])
            if m2:
                stop = min(stop, head + m2.start())
        part = rest[:stop]
        if re.search(r"%|disabled|No Data", part, re.I):
            return part
    return ""


def widget_value(part):
    """Highest real reading in a widget. Labelled values ('avg 36%', 'Used 25%')
    win; bare numbers on their own line are chart axis ticks and are skipped,
    as are threshold lines ('Critical 90%')."""
    avg = [pct(v) for v in re.findall(r"avg\w*\s*:?\s*(\d+(?:\.\d+)?)\s*%", part, re.I)]
    if avg:
        return max(avg)
    vals = []
    for line in part.splitlines():
        if not re.search(r"[A-Za-z]", line):
            continue
        for m in re.finditer(r"(\d+(?:\.\d+)?)\s*%", line):
            if re.search(r"(critical|warning|threshold)\W{0,15}$", line[max(0, m.start() - 25):m.start()], re.I):
                continue
            vals.append(pct(m.group(1)))
    return max(vals) if vals else None


def read_unit_page(text):
    """Pull status, CPU, memory and disk out of a Health Monitor unit page."""
    out = {"status": "", "cpu": None, "cpu_note": "", "memory": None, "disk": {}, "lines": []}
    m = re.search(rf"Health:\s*.+?\s*[–—-]\s*({STATUS_WORDS})", text)
    if m:
        out["status"] = m.group(1)

    heads = ["CPU", "Memory", "Interface", "Disk", "Throughput", "Connections",
             "Process", "Snort", "ASP Drops", "Event Capacity", "Critical Partition"]
    cpu = section(text, "CPU", [h for h in heads if h != "CPU"])
    if re.search(r"data collection for cpu module is disabled", cpu or text, re.I):
        out["cpu_note"] = "not collected (CPU module disabled in health policy)"
    else:
        out["cpu"] = widget_value(cpu)

    mem = section(text, "Memory", [h for h in heads if h != "Memory"])
    out["memory"] = widget_value(mem)

    m = re.search(r"Entire Disk\D{0,30}?(\d+(?:\.\d+)?)\s*%", text, re.I)
    if m:
        out["disk"]["Entire Disk"] = pct(m.group(1))
    for name, v in re.findall(r"(?<![\w/])(/[\w./-]*)\s*[:=]?\s*(\d+(?:\.\d+)?)\s*%", text):
        out["disk"].setdefault(name, pct(v))
    for name, v in re.findall(r"(/[\w./-]*)\s+using\s+(\d+(?:\.\d+)?)%", text):
        out["disk"][name] = pct(v)

    # lines that explain a non-Normal status
    for line in text.splitlines():
        line = line.strip()
        if 10 < len(line) < 300 and re.search(
                r"disabled in the health|critical|not reachable|unreachable|disconnected|"
                r"failed|failure|down\b|exceed|over capacity|threshold", line, re.I):
            if not re.match(rf"^Health:", line) and line not in out["lines"]:
                out["lines"].append(line)
    return out


def count_records(text):
    if re.search(r"\bNo Records\b", text, re.I):
        return 0
    m = re.search(r"\bof\s+([\d,]+)\b", text)
    return int(m.group(1).replace(",", "")) if m else None


# ----------------------------------------------------------------- browser

class Fmc:
    def __init__(self, s, out_dir, show):
        self.s, self.out_dir, self.show = s, out_dir, show
        self.base = f"{s['protocol']}://{s['fmc']}"
        self.shots = []
        self.timeout = int(s["page_timeout_seconds"]) * 1000

    def start(self, pw):
        channels = [self.s["browser"]] + [c for c in ("msedge", "chrome", "chromium") if c != self.s["browser"]]
        last = None
        for ch in channels:
            try:
                kw = {"headless": not self.show}
                if ch != "chromium":
                    kw["channel"] = ch
                self.browser = pw.chromium.launch(**kw)
                log(f"Browser: {ch}{'' if self.show else ' (hidden)'}")
                break
            except Exception as e:  # missing browser or blocked by policy
                last = e
        else:
            raise RuntimeError(f"could not start Edge or Chrome: {last}")
        self.ctx = self.browser.new_context(ignore_https_errors=True, viewport={"width": 1600, "height": 1000})
        self.page = self.ctx.new_page()
        self.page.set_default_timeout(self.timeout)

    def settle(self, seconds=None):
        try:
            self.page.wait_for_load_state("networkidle", timeout=self.timeout)
        except Exception:
            pass
        time.sleep(self.s["settle_seconds"] if seconds is None else seconds)

    def text(self):
        try:
            return self.page.inner_text("body")
        except Exception:
            return ""

    def snap(self, name):
        safe = re.sub(r"[^\w.-]+", "_", name)
        path = self.out_dir / f"{len(self.shots) + 1:02d}-{safe}.png"
        try:
            self.page.screenshot(path=str(path), full_page=True)
            (path.with_suffix(".txt")).write_text(f"URL: {self.page.url}\n\n{self.text()}", encoding="utf-8")
            self.shots.append(path)
        except Exception as e:
            log(f"  (screenshot failed: {e})")
        return path

    def go(self, key):
        url = self.s["pages"][key]
        if url:
            self.page.goto(self.base + url, wait_until="domcontentloaded")
        self.settle()

    def click_text(self, *labels, exact=False):
        for label in labels:
            for loc in (self.page.get_by_role("treeitem", name=label, exact=exact),
                        self.page.get_by_role("tab", name=label, exact=exact),
                        self.page.get_by_role("link", name=label, exact=exact),
                        self.page.get_by_role("button", name=label, exact=exact),
                        self.page.get_by_text(label, exact=exact)):
                try:
                    if loc.count() and loc.first.is_visible():
                        loc.first.click()
                        return True
                except Exception:
                    continue
        return False

    def accept_prompts(self):
        # login banner / "session already active" style prompts
        for label in ("I Agree", "Agree", "Accept", "Acknowledge", "Continue", "Proceed", "OK"):
            loc = self.page.get_by_role("button", name=label, exact=True)
            try:
                if loc.count() and loc.first.is_visible():
                    loc.first.click()
                    self.settle(2)
            except Exception:
                pass

    def login(self, password):
        p = self.page
        p.goto(self.base + self.s["pages"]["login"], wait_until="domcontentloaded")
        self.settle(2)
        self.accept_prompts()
        user = p.locator('input[name="username"], #username, input[autocomplete="username"], input[type="text"]').first
        user.wait_for(state="visible")
        user.fill(self.s["username"])
        p.locator('input[type="password"]').first.fill(password)
        if not self.click_text("Log In", "Login", "Sign In", exact=False):
            p.keyboard.press("Enter")
        self.settle(3)
        self.accept_prompts()
        if p.locator('input[type="password"]').count() and p.locator('input[type="password"]').first.is_visible():
            msg = ""
            for line in self.text().splitlines():
                if re.search(r"invalid|incorrect|failed|denied|unable|locked|not authori", line, re.I):
                    msg = line.strip()
                    break
            self.snap("login-failed")
            raise RuntimeError(f"login to FMC failed: {msg or 'still on the login page'}")
        log(f"Logged in to {self.base} as {self.s['username']}")

    def pick_time_range(self):
        want = self.s.get("time_range")
        if not want:
            return
        try:
            opener = self.page.get_by_text(re.compile(r"Last \d+ (hour|hours|minutes|day|days)", re.I))
            if opener.count() and opener.first.is_visible():
                current = opener.first.inner_text().strip()
                if want.lower() not in current.lower():
                    opener.first.click()
                    time.sleep(1)
                    if self.click_text(want, exact=False):
                        self.settle()
                    else:
                        self.page.keyboard.press("Escape")
        except Exception:
            pass

    def logout(self):
        try:
            if self.click_text(self.s["username"], exact=False):
                time.sleep(1)
                if self.click_text("Log Out", "Logout", exact=False):
                    self.settle(2)
                    log("Logged out")
        except Exception:
            pass

    def close(self):
        try:
            self.browser.close()
        except Exception:
            pass


# ----------------------------------------------------------------- the check

def run_check(s, password, out_dir, show):
    from playwright.sync_api import sync_playwright

    rows, info = [], {"fmc_text": "", "events": {}}
    with sync_playwright() as pw:
        fmc = Fmc(s, out_dir, show)
        fmc.start(pw)
        try:
            fmc.login(password)

            # 1. Summary Dashboard > Status
            log("Summary Dashboard > Status")
            fmc.go("dashboard")
            if not fmc.click_text("Status", exact=True):
                fmc.click_text("Overview")
                time.sleep(1)
                fmc.click_text("Summary Dashboard", "Dashboards")
                fmc.settle()
                fmc.click_text("Status", exact=True)
            fmc.settle()
            dash = fmc.text()
            fmc.snap("dashboard-status")
            m = re.search(r"Software Version\s*:?\s*([\d.]+(?:\s*\(build \d+\))?)", dash, re.I) or \
                re.search(r"Software\s*:?\s*([\d.]+)", dash)
            info["version"] = m.group(1) if m else ""
            m = re.search(r"Model\s*:?\s*(.+)", dash)
            info["model"] = m.group(1).strip() if m else ""
            m = re.search(r"Uptime\s*:?\s*(.+)", dash)
            info["uptime"] = m.group(1).strip() if m else ""
            info["appliance_status"] = ", ".join(f"{w} ({n})" for w, n in re.findall(
                rf"\b({STATUS_WORDS})\s*\((\d+)\)", dash))

            # 2. Health Monitor
            log("System > Health > Monitor")
            fmc.go("health")
            fmc.pick_time_range()
            tree = fmc.text()
            fmc.snap("health-monitor")
            m = re.search(r"(\d+)\s*total.{0,40}?(\d+)\s*critical.{0,40}?(\d+)\s*warning", tree, re.I | re.S)
            info["summary"] = f"{m.group(1)} total, {m.group(2)} critical, {m.group(3)} warning" if m else ""

            units = s["units"] or [s["fmc_unit_name"]]
            for unit in units:
                is_fmc = unit == s["fmc_unit_name"]
                row = Row(unit, "FMC" if is_fmc else "Firewall")
                rows.append(row)
                log(f"  {unit}")
                role = re.search(rf"{re.escape(unit)}\s*\(\s*(Active|Standby|Failed|Disabled|[A-Za-z ]+?)\s*\)", tree)
                if role:
                    row.role = role.group(1)
                if unit not in tree:
                    row.add("FAIL", "not found in Health Monitor (removed or not registered?)")
                    continue
                fmc.go("health")
                if not fmc.click_text(unit, exact=False):
                    row.add("FAIL", "could not open its health page")
                    continue
                fmc.settle()
                fmc.pick_time_range()
                text = fmc.text()
                fmc.snap(f"health-{unit}")
                data = read_unit_page(text)
                judge_unit(row, data, s)

            judge_ha(rows, s)

            # 3. Events
            if s["check_events"]:
                for key, label in (("intrusions", "Intrusion events"), ("connections", "Connection events")):
                    log(f"Analysis > {label}")
                    try:
                        fmc.go(key)
                        text = fmc.text()
                        fmc.snap(key)
                        n = count_records(text)
                        blocks = len(re.findall(r"(?m)^\s*Block\b|\tBlock\t", text))
                        info["events"][label] = {"count": n, "blocks_on_page": blocks}
                    except Exception as e:
                        info["events"][label] = {"count": None, "error": str(e)}
                ev = info["events"].get("Intrusion events", {})
                row = Row("Intrusion events", "Events")
                row.health = "" if ev.get("count") is None else f"{ev['count']:,} shown"
                if ev.get("count") is None:
                    row.add("WARNING", "could not read the intrusion events page")
                elif ev["count"] > 0:
                    row.add("WARNING", f"{ev['count']:,} intrusion events, please review in FMC")
                rows.append(row)
            fmc.logout()
        finally:
            fmc.close()
    return rows, info, fmc.shots


def judge_unit(row, data, s):
    row.health = data["status"] or "unknown"
    ignore = s["ignore_alerts"]

    if data["cpu"] is not None:
        row.cpu = f"{data['cpu']:g}%"
        if data["cpu"] > s["cpu_warn_percent"]:
            row.add("WARNING", f"CPU at {data['cpu']:g}%, above {s['cpu_warn_percent']}%")
    else:
        row.cpu = data["cpu_note"] or "no data"
    if data["memory"] is not None:
        row.memory = f"{data['memory']:g}%"
        if data["memory"] > s["memory_warn_percent"]:
            row.add("WARNING", f"memory at {data['memory']:g}%, above {s['memory_warn_percent']}%")
    else:
        row.memory = "no data"
    row.disk = ", ".join(f"{k} {v:g}%" for k, v in data["disk"].items()) or "no data"
    for name, v in data["disk"].items():
        if v >= s["disk_fail_percent"]:
            row.add("FAIL", f"disk {name} at {v:g}%")
        elif v >= s["disk_warn_percent"]:
            row.add("WARNING", f"disk {name} at {v:g}%")

    reasons = [l for l in data["lines"] if not is_ignored(l, ignore)]
    known = [l for l in data["lines"] if is_ignored(l, ignore)]
    for l in known:
        row.notes.append(f"ignored (known): {l}")
    status = row.health.lower()
    if re.search(r"not reachable|unreachable|disconnected", " ".join(data["lines"]), re.I):
        row.add("FAIL", "not connected to the FMC")
    if status in ("critical", "error"):
        if reasons:
            row.add("FAIL", "Critical: " + "; ".join(reasons[:3]))
        elif not known:
            row.add("FAIL", "health is Critical (open the screenshot for the reason)")
    elif status == "warning":
        if reasons:
            row.add("WARNING", "Warning: " + "; ".join(reasons[:3]))
        elif not known:
            row.add("WARNING", "health is Warning (open the screenshot for the reason)")
    elif status == "disabled":
        row.add("WARNING", "health monitoring is disabled for this unit")
    elif status == "unknown":
        row.add("WARNING", "could not read the health status from the page")


def judge_ha(rows, s):
    by_name = {r.unit: r for r in rows}
    for pair, members in s["ha_pairs"].items():
        row = Row(pair, "HA pair")
        roles = {m: (by_name[m].role if m in by_name else "") for m in members}
        row.role = " / ".join(f"{m} {r or '?'}" for m, r in roles.items())
        active = [m for m, r in roles.items() if r.lower() == "active"]
        standby = [m for m, r in roles.items() if r.lower() == "standby"]
        if not active:
            row.add("FAIL", "no unit is Active")
        if not standby:
            row.add("FAIL", "no unit is Standby")
        want = s["ha_expected_active"].get(pair)
        if want and active and active[0] != want:
            row.add("WARNING", f"failover happened: {active[0]} is Active, normally {want}")
        rows.append(row)


# ----------------------------------------------------------------- report

def overall(rows, error):
    if error:
        return "FAIL"
    return max((r.result for r in rows), key=RANK.get, default="FAIL")


def comments(rows, error):
    if error:
        return f"Check could not run: {error}"
    bad = [f"{r.unit}: {'; '.join(f.split(': ', 1)[1] for f in r.findings)}" for r in rows if r.findings]
    return "<br>".join(html.escape(b) for b in bad) or "Checks have been completed. There is nothing to report."


def build_html(s, rows, info, error, result, stamp):
    e = html.escape
    colour = {"PASS": "#1e7b34", "WARNING": "#b36b00", "FAIL": "#b00020"}
    td = 'style="border:1px solid #999;padding:6px;vertical-align:top"'
    th = 'style="border:1px solid #999;padding:6px;background:#dbe5f1;text-align:left"'
    sig = e(s["email"].get("signature", "")).replace("\\n", "<br>").replace("\n", "<br>")
    out = [f'<html><body style="font-family:Calibri,Arial,sans-serif;font-size:11pt">',
           "<p>Good Morning All,</p><p>Daily production checks have been completed, and the results are as follows.</p>",
           f'<table style="border-collapse:collapse"><tr><th {th}>Checklist</th><th {th}>Steps</th>'
           f'<th {th}>Assigned to</th><th {th}>Completed</th><th {th}>Comments</th></tr>',
           f'<tr><td {td}>Check Firewall</td><td {td}>FMC {e(s["fmc"])}: dashboard status, Health Monitor '
           f'(health, HA, CPU, memory, disk, critical partitions), intrusion and connection events</td>'
           f'<td {td}>{e(s["assigned_to"])}</td><td {td}>{e(stamp)}</td>'
           f'<td {td}><b style="color:{colour[result]}">{result}</b> {comments(rows, error)}</td></tr></table>']
    if info.get("version") or info.get("summary"):
        out.append(f"<p>FMC {e(s['fmc'])}: {e(info.get('model', ''))} version {e(info.get('version', ''))}, "
                   f"uptime {e(info.get('uptime', ''))}. Health Monitor: {e(info.get('summary', ''))}.</p>")
    if rows:
        out.append(f'<table style="border-collapse:collapse"><tr>' + "".join(
            f"<th {th}>{h}</th>" for h in ("Unit", "Type", "Result", "Health", "HA role", "CPU", "Memory", "Disk", "Details")) + "</tr>")
        for r in rows:
            details = "<br>".join(e(x) for x in r.findings + r.notes) or "OK"
            out.append(f"<tr><td {td}>{e(r.unit)}</td><td {td}>{e(r.kind)}</td>"
                       f'<td {td}><b style="color:{colour[r.result]}">{r.result}</b></td><td {td}>{e(r.health)}</td>'
                       f"<td {td}>{e(r.role)}</td><td {td}>{e(r.cpu)}</td><td {td}>{e(r.memory)}</td>"
                       f"<td {td}>{e(r.disk)}</td><td {td}>{details}</td></tr>")
        out.append("</table>")
    if info.get("events"):
        parts = []
        for label, ev in info["events"].items():
            n = ev.get("count")
            parts.append(f"{label}: {'could not read' if n is None else f'{n:,}'}")
        out.append(f"<p>{e('; '.join(parts))} (as shown on the FMC event pages; screenshots attached). "
                   "Unusual traffic still needs an engineer's review.</p>")
    out.append(f"<p>{sig}</p></body></html>")
    return "\n".join(out)


def write_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Unit", "Type", "Result", "Health", "HA role", "CPU", "Memory", "Disk", "Details"])
        for r in rows:
            w.writerow([r.unit, r.kind, r.result, r.health, r.role, r.cpu, r.memory, r.disk, " | ".join(r.findings + r.notes)])


def send_email(s, result, html_body, attachments, stamp):
    m = s["email"]
    if not m.get("enabled", True):
        log("Email: switched off in settings")
        return True
    if m.get("send_when", "always") == "problems" and result == "PASS":
        log("Email: not sent (PASS and send_when is \"problems\")")
        return True
    to = [x for x in m.get("to", []) if x and "CHANGE-ME" not in x]
    if not to or not m.get("from") or "CHANGE-ME" in m.get("from", ""):
        log("Email: NOT sent - fill in email from/to in the settings file")
        return False
    subject = m.get("subject", "Daily Production Checks - Firewall {date}").replace("{date}", stamp)
    if result != "PASS":
        subject = f"[{result}] {subject}"
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = subject, m["from"], ", ".join(to)
    cc = [x for x in m.get("cc", []) if x]
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg.set_content("This email needs an HTML capable mail client.")
    msg.add_alternative(html_body, subtype="html")
    for p in attachments:
        data = Path(p).read_bytes()
        maintype, subtype = ("image", "png") if p.suffix == ".png" else ("text", "csv")
        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=p.name)
    try:
        if m.get("pickup_folder"):
            folder = Path(m["pickup_folder"])
            folder.mkdir(parents=True, exist_ok=True)
            (folder / f"firewall-{stamp.replace(':', '').replace(' ', '-')}.eml").write_bytes(bytes(msg))
            log(f"Email: saved as a file in {folder} (test mode)")
            return True
        port = int(m.get("port", 25))
        smtp = smtplib.SMTP_SSL(m["smtp_server"], port, timeout=60) if port == 465 else smtplib.SMTP(m["smtp_server"], port, timeout=60)
        with smtp:
            if m.get("use_ssl") and port != 465:
                smtp.starttls()
            if m.get("username"):
                smtp.login(m["username"], os.environ.get("SMTP_PASSWORD", ""))
            smtp.send_message(msg, to_addrs=to + cc)
        log(f"Email: sent to {', '.join(to + cc)}")
        return True
    except Exception as e:
        log(f"Email: FAILED - {e}")
        return False


# ----------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser(description="FMC firewall health check (browser based)")
    ap.add_argument("--settings", default="config/firewall.settings.json")
    ap.add_argument("--show", action="store_true", help="show the browser window")
    ap.add_argument("--no-email", action="store_true")
    a = ap.parse_args()

    s = read_settings(a.settings)
    now = dt.datetime.now()
    stamp, file_stamp = now.strftime("%Y-%m-%d %H:%M"), now.strftime("%Y%m%d-%H%M")
    reports = Path("reports")
    shots_dir = reports / f"firewall-screens-{file_stamp}"
    shots_dir.mkdir(parents=True, exist_ok=True)

    password = os.environ.get("FMC_PASSWORD")
    if not password:
        if os.environ.get("CI") or not sys.stdin.isatty():
            log("ERROR: FMC_PASSWORD is not set (add it under Settings > CI/CD > Variables)")
            return 1
        password = getpass.getpass(f"FMC password for {s['username']}: ")

    log(f"Firewall health check {stamp}  FMC {s['fmc']}")
    rows, info, shots, error = [], {}, [], ""
    try:
        rows, info, shots = run_check(s, password, shots_dir, a.show or s["show_browser"])
    except ImportError:
        error = "Playwright is not installed (pip install playwright)"
    except Exception as e:
        error = str(e).splitlines()[0][:300]
    shots = shots or sorted(shots_dir.glob("*.png"))

    result = overall(rows, error)
    log("")
    if error:
        log(f"ERROR: {error}")
    for r in rows:
        log(f"{r.unit:<28} {r.kind:<9} {r.result:<8} " + ("; ".join(r.findings) or "OK"))
        for n in r.notes:
            log(f"{'':<47} {n}")
    log(f"OVERALL: {result}")

    page = build_html(s, rows, info, error, result, stamp)
    html_path = reports / f"firewall-{file_stamp}.html"
    csv_path = reports / f"firewall-{file_stamp}.csv"
    html_path.write_text(page, encoding="utf-8")
    write_csv(csv_path, rows)
    log(f"Report: {html_path}  {csv_path}  {shots_dir}")

    if not a.no_email:
        sent = send_email(s, result, page, [csv_path] + list(shots), stamp)
        if not sent and result == "PASS":
            result = "WARNING"
    return {"PASS": 0, "WARNING": 2, "FAIL": 1}[result]


if __name__ == "__main__":
    sys.exit(main())
