@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
echo.
echo Done. Playwright uses the Edge browser already on this PC.
pause
