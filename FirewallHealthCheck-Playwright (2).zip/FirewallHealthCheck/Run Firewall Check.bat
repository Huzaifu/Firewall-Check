@echo off
cd /d "%~dp0"
python fmc_health_check.py --settings config\firewall.settings.json --show
echo.
pause
