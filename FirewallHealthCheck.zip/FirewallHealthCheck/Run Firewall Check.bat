@echo off
rem Runs the firewall health check with config\firewall.settings.json (asks for the FMC password).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FirewallHealthCheck.ps1" -SettingsPath "%~dp0config\firewall.settings.json"
pause
