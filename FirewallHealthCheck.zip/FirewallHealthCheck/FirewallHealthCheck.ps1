<#
Daily firewall health check for Cisco Secure Firewall Management Center (FMC).

Reads, through FMC's built-in REST connection (read only, changes nothing):
  - FMC version and uptime
  - every managed firewall: connected, health status, version
  - HA pairs: which unit is Active / Standby, config in sync
  - health alerts (FMC and firewalls) from the last N hours
  - CPU and memory usage, disk usage and critical partitions
Then writes a report (HTML, CSV, raw JSON) and emails it in the same format as
the "Daily Production Checks" email.

Made to run in a GitLab pipeline (no window). By hand:
    powershell -ExecutionPolicy Bypass -File .\FirewallHealthCheck.ps1 [-SettingsPath config\firewall.settings.json] [-NoEmail]

Passwords come from environment variables (GitLab CI/CD variables):
    FMC_PASSWORD    the FMC account password
    SMTP_PASSWORD   only if the mail server needs a login
Exit code: 0 PASS, 2 WARNING, 1 FAIL or error.

Runs on the PowerShell built into Windows (5.1) and on PowerShell 7.
#>
[CmdletBinding()]
param(
    [string]$SettingsPath,
    [switch]$NoEmail
)

$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
if (-not $SettingsPath) { $SettingsPath = Join-Path $Root 'config\firewall.settings.json' }

if (-not ('NsTls' -as [type])) {
    Add-Type -TypeDefinition @"
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
public static class NsTls {
    static bool Accept(object s, X509Certificate c, X509Chain ch, SslPolicyErrors e) { return true; }
    public static readonly RemoteCertificateValidationCallback Callback = Accept;
}
"@
}
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

function Write-Line($m) { Write-Host $m }

# ---------------------------------------------------------------- settings

function Read-Settings {
    if (-not (Test-Path -LiteralPath $SettingsPath)) { throw "Settings file not found: $SettingsPath" }
    $j = Get-Content -LiteralPath $SettingsPath -Raw | ConvertFrom-Json
    $s = [ordered]@{
        fmc                 = "$($j.fmc)".Trim()
        username            = "$($j.username)".Trim()
        protocol            = if ($j.protocol) { "$($j.protocol)" } else { 'https' }
        devices             = @($j.devices | Where-Object { $_ } | ForEach-Object { "$_".Trim() })
        alert_hours         = if ($j.alert_hours) { [int]$j.alert_hours } else { 24 }
        cpu_warn_percent    = if ($j.cpu_warn_percent) { [double]$j.cpu_warn_percent } else { 50 }
        memory_warn_percent = if ($j.memory_warn_percent) { [double]$j.memory_warn_percent } else { 50 }
        disk_warn_percent   = if ($j.disk_warn_percent) { [double]$j.disk_warn_percent } else { 80 }
        disk_fail_percent   = if ($j.disk_fail_percent) { [double]$j.disk_fail_percent } else { 90 }
        ha_expected_active  = @{}
        ignore_alerts       = @($j.ignore_alerts | Where-Object { $_ } | ForEach-Object { "$_" })
        assigned_to         = if ($j.assigned_to) { "$($j.assigned_to)" } else { 'Contractor' }
        email               = $j.email
    }
    if ($j.ha_expected_active) {
        foreach ($p in $j.ha_expected_active.PSObject.Properties) { $s.ha_expected_active[$p.Name] = "$($p.Value)" }
    }
    if (-not $s.fmc) { throw '"fmc" is empty in the settings file' }
    if (-not $s.username) { throw '"username" is empty in the settings file' }
    $s
}

# ---------------------------------------------------------------- FMC connection

function Invoke-Fmc($S, [string]$Method, [string]$Path, [switch]$WithHeaders) {
    try {
        $req = [System.Net.WebRequest]::Create($S.Base + $Path)
        $req.Method = $Method
        $req.Proxy = $null
        $req.Accept = 'application/json'
        $req.Timeout = 120000
        $req.ReadWriteTimeout = 120000
        if ($S.Protocol -eq 'https') { $req.ServerCertificateValidationCallback = [NsTls]::Callback }
        if ($S.Basic) { $req.Headers.Add('Authorization', "Basic $($S.Basic)") }
        if ($S.Token) { $req.Headers.Add('X-auth-access-token', $S.Token) }
        if ($Method -eq 'POST') { $req.ContentLength = 0 }
        $resp = $req.GetResponse()
    }
    catch {
        $e = $_.Exception
        while ($e -and -not ($e -is [System.Net.WebException]) -and $e.InnerException) { $e = $e.InnerException }
        if ($e -is [System.Net.WebException] -and $e.Response) {
            $code = [int]$e.Response.StatusCode
            $raw = ''
            try { $raw = (New-Object IO.StreamReader($e.Response.GetResponseStream())).ReadToEnd() } catch { }
            $msg = $raw
            try {
                $j = $raw | ConvertFrom-Json
                $d = @($j.error.messages | ForEach-Object { $_.description }) -join '; '
                if ($d) { $msg = $d }
            } catch { }
            if ($code -eq 401) { $msg = "not authorised ($msg)" }
            if ($code -eq 429) { $msg = 'too many requests, FMC rate limit' }
            throw "$Method $Path failed ($code): $msg"
        }
        throw "cannot reach $($S.Address): $($e.Message)"
    }
    $headers = @{}
    foreach ($k in $resp.Headers.AllKeys) { $headers[$k] = $resp.Headers[$k] }
    $reader = New-Object IO.StreamReader($resp.GetResponseStream())
    $raw = $reader.ReadToEnd()
    $reader.Close(); $resp.Close()
    $data = if ($raw.Trim()) { $raw | ConvertFrom-Json } else { $null }
    if ($WithHeaders) { return @{ Data = $data; Headers = $headers } }
    $data
}

function Connect-Fmc($Address, $Protocol, $User, $Pass) {
    $basic = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("${User}:$Pass"))
    $protocols = if ($Protocol -eq 'auto') { @('https', 'http') } else { @($Protocol) }
    $lastErr = $null
    foreach ($p in $protocols) {
        $S = @{ Address = $Address; Protocol = $p; Base = "${p}://$Address"; Basic = $basic; Token = $null; Domain = $null }
        try {
            $r = Invoke-Fmc $S POST '/api/fmc_platform/v1/auth/generatetoken' -WithHeaders
            $S.Basic = $null
            $S.Token = $r.Headers['X-auth-access-token']
            $S.Domain = $r.Headers['DOMAIN_UUID']
            if (-not $S.Token) { throw 'FMC returned no access token' }
            if (-not $S.Domain -and $r.Headers['DOMAINS']) {
                $doms = $r.Headers['DOMAINS'] | ConvertFrom-Json
                $S.Domain = @($doms | Where-Object { $_.name -eq 'Global' })[0].uuid
            }
            if (-not $S.Domain) { throw 'FMC returned no domain' }
            return $S
        }
        catch {
            $lastErr = "$_"
            if ($lastErr -notmatch '^cannot reach') { break }
        }
    }
    throw "login to FMC failed: $lastErr"
}

function Disconnect-Fmc($S) {
    if (-not $S -or -not $S.Token) { return }
    # not in every FMC version; harmless if refused, the token also expires after 30 minutes
    try { Invoke-Fmc $S POST '/api/fmc_platform/v1/auth/revokeaccess' | Out-Null } catch { }
    $S.Token = $null
}

function Get-FmcItems($S, [string]$Path) {
    $all = @()
    $offset = 0
    $sep = if ($Path.Contains('?')) { '&' } else { '?' }
    while ($true) {
        $r = Invoke-Fmc $S GET "$Path${sep}offset=$offset&limit=1000"
        $items = @($r.items | Where-Object { $_ })
        $all += $items
        $more = $r.paging -and $r.paging.next -and $items.Count -gt 0
        if (-not $more) { break }
        $offset += $items.Count
        if ($offset -gt 20000) { break }
    }
    $all
}

function Get-Filter([hashtable]$Parts, [string[]]$Order) {
    $text = ($Order | Where-Object { $Parts.ContainsKey($_) } | ForEach-Object { "${_}:$($Parts[$_])" }) -join ';'
    'filter=' + [Uri]::EscapeDataString($text)
}

# ---------------------------------------------------------------- readings

function Get-Metric($S, $DeviceId, $Metric, $Regex, $Start, $End) {
    # result: @{ label = @{ Latest = n; Peak = n } }, empty when the module is off in the health policy
    $f = Get-Filter @{ metric = $Metric; deviceUUIDs = $DeviceId; startTime = $Start; endTime = $End; step = 300; regexFilter = $Regex } `
        @('metric', 'deviceUUIDs', 'startTime', 'endTime', 'step', 'regexFilter')
    $r = Invoke-Fmc $S GET "/api/fmc_config/v1/domain/$($S.Domain)/health/metrics?$f"
    $out = @{}
    foreach ($item in @($r.items | Where-Object { $_ })) {
        $body = $item.response
        if ($body -is [string]) { $body = $body | ConvertFrom-Json }
        foreach ($series in @($body.data.result | Where-Object { $_ })) {
            $label = $null
            foreach ($p in $series.metric.PSObject.Properties) {
                if ($p.Name -notin @('__name__', 'uuid', 'deviceUUID', 'instance', 'job')) { $label = "$($p.Value)"; break }
            }
            if (-not $label) { $label = $Metric }
            $vals = @($series.values | ForEach-Object { [double]"$($_[1])" })
            if ($vals.Count -eq 0) { continue }
            $out[$label] = @{ Latest = $vals[-1]; Peak = ($vals | Measure-Object -Maximum).Maximum }
        }
    }
    $out
}

function Get-DiskFromAlerts($Alerts) {
    # DISK_USAGE details look like "/ngfw using 4%: 2.1G (55G Avail) of 61G"
    $parts = [ordered]@{}
    foreach ($a in $Alerts) {
        if ("$($a.moduleID)" -notmatch 'DISK') { continue }
        foreach ($m in [regex]::Matches("$($a.details)", '(\S+)\s+using\s+(\d+(?:\.\d+)?)%')) {
            $parts[$m.Groups[1].Value] = [double]$m.Groups[2].Value
        }
    }
    $parts
}

# ---------------------------------------------------------------- check

function New-Row($Unit, $Kind) {
    [ordered]@{
        Unit = $Unit; Type = $Kind; Role = ''; Connected = ''; Health = ''; Version = ''
        Cpu = ''; Memory = ''; Disk = ''; Result = 'PASS'; Findings = @()
    }
}

function Add-Finding($Row, [string]$Level, [string]$Text) {
    $Row.Findings += "$Level`: $Text"
    if ($Level -eq 'FAIL') { $Row.Result = 'FAIL' }
    elseif ($Level -eq 'WARNING' -and $Row.Result -eq 'PASS') { $Row.Result = 'WARNING' }
}

function Test-Ignored($Settings, $Alert) {
    $text = "$($Alert.moduleID) $($Alert.details)"
    foreach ($p in $Settings.ignore_alerts) { if ($text -like "*$p*") { return $true } }
    $false
}

function Format-Pct($v) {
    if ($null -eq $v -or "$v" -eq '') { return '' }
    [string]::Format([Globalization.CultureInfo]::InvariantCulture, '{0:0.#}%', [double]$v)
}

function Invoke-FirewallCheck($Settings, $Pass, $RawDir) {
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $start = $now - ($Settings.alert_hours * 3600)
    $S = Connect-Fmc $Settings.fmc $Settings.protocol $Settings.username $Pass
    $rows = @(); $info = @{}; $notes = @()
    try {
        Write-Line "Connected to FMC $($Settings.fmc) over $($S.Protocol)"
        $save = {
            param($name, $obj)
            $file = ($name -replace '[^\w\.-]', '_') + '.json'
            ConvertTo-Json -InputObject $obj -Depth 12 | Set-Content -Path (Join-Path $RawDir $file) -Encoding UTF8
        }

        # FMC itself
        $ver = @((Invoke-Fmc $S GET '/api/fmc_platform/v1/info/serverversion').items)[0]
        & $save 'serverversion' $ver
        $info.FmcVersion = "$($ver.serverVersion)"
        $info.FmcModel = "$($ver.model)"
        $info.FmcName = if ($ver.hostname) { "$($ver.hostname)" } else { "FMC $($Settings.fmc)" }
        $info.FmcUptime = "$($ver.uptime)"
        Write-Line "FMC: $($info.FmcName)  $($info.FmcModel)  version $($info.FmcVersion)  up $($info.FmcUptime)"

        # managed firewalls
        $devices = @(Get-FmcItems $S "/api/fmc_config/v1/domain/$($S.Domain)/devices/devicerecords?expanded=true")
        & $save 'devicerecords' $devices
        if ($Settings.devices.Count) {
            $missing = @($Settings.devices | Where-Object { @($devices.name) -notcontains $_ })
            foreach ($m in $missing) { $notes += "FAIL: firewall '$m' from the settings file is not in FMC" }
            $devices = @($devices | Where-Object { $Settings.devices -contains $_.name })
        }
        $names = @{ '0' = $info.FmcName }
        foreach ($d in $devices) { $names["$($d.id)"] = "$($d.name)" }

        # HA pairs
        $pairs = @()
        try { $pairs = @(Get-FmcItems $S "/api/fmc_config/v1/domain/$($S.Domain)/devicehapairs/ftddevicehapairs?expanded=true") }
        catch { $notes += "WARNING: could not read HA pairs ($_)" }
        & $save 'hapairs' $pairs

        # health alerts for the FMC (id 0) and the firewalls
        $ids = @('0') + @($devices | ForEach-Object { "$($_.id)" })
        $alerts = @()
        $alertPath = "/api/fmc_config/v1/domain/$($S.Domain)/health/alerts?"
        try {
            $f = Get-Filter @{ startTime = $start; endTime = $now; deviceUUIDs = ($ids -join ',') } @('startTime', 'endTime', 'deviceUUIDs')
            $alerts = @(Get-FmcItems $S "$alertPath$f")
        }
        catch {
            # some versions refuse the FMC (0) mixed with firewalls; ask one unit at a time
            foreach ($id in $ids) {
                try {
                    $f = Get-Filter @{ startTime = $start; endTime = $now; deviceUUIDs = $id } @('startTime', 'endTime', 'deviceUUIDs')
                    $alerts += @(Get-FmcItems $S "$alertPath$f")
                }
                catch { $notes += "WARNING: could not read health alerts for $($names[$id]) ($_)" }
            }
        }
        & $save 'healthalerts' $alerts
        # FMC repeats the same module many times; keep the newest per unit and module
        $latest = @{}
        foreach ($a in ($alerts | Sort-Object { [double]"$($_.timestamp)" })) { $latest["$($a.deviceUUID)|$($a.moduleID)"] = $a }
        $current = @($latest.Values)

        # one row for the FMC, one per firewall
        $units = @(@{ Id = '0'; Name = $info.FmcName; Kind = 'FMC'; Device = $null }) +
            @($devices | ForEach-Object { @{ Id = "$($_.id)"; Name = "$($_.name)"; Kind = 'Firewall'; Device = $_ } })
        foreach ($u in $units) {
            $row = New-Row $u.Name $u.Kind
            if ($u.Kind -eq 'FMC') {
                # FMC alerts come back as device 0; anything not a known firewall is also the FMC's
                $known = @($devices | ForEach-Object { "$($_.id)" })
                $mine = @($current | Where-Object { $known -notcontains "$($_.deviceUUID)" })
            }
            else { $mine = @($current | Where-Object { "$($_.deviceUUID)" -eq $u.Id }) }
            if ($u.Kind -eq 'FMC') {
                $row.Version = $info.FmcVersion
                $row.Connected = 'yes'
                $worst = 'green'
                foreach ($a in $mine) {
                    if ("$($a.status)" -match 'RED') { $worst = 'red' }
                    elseif ("$($a.status)" -match 'YELLOW' -and $worst -ne 'red') { $worst = 'yellow' }
                }
                $row.Health = $worst
            }
            else {
                $d = $u.Device
                $row.Version = "$($d.sw_version)"
                $row.Connected = if ("$($d.isConnected)" -match 'false') { 'NO' } else { 'yes' }
                $row.Health = "$($d.healthStatus)"
                $cd = $d.metadata.containerDetails
                if ($cd -and $cd.status) { $row.Role = "$($cd.status)" }
                if ($row.Connected -eq 'NO') { Add-Finding $row 'FAIL' 'not connected to FMC' }
            }

            # health alerts
            foreach ($a in $mine) {
                $st = "$($a.status)".ToUpper()
                if ($st -notmatch 'RED|YELLOW|FAIL|ERROR') { continue }
                $text = "$($a.moduleID): $($a.details)".Trim()
                if (Test-Ignored $Settings $a) { $row.Findings += "ignored (known): $text"; continue }
                if ($st -match 'RED|FAIL|ERROR') { Add-Finding $row 'FAIL' "critical health alert $text" }
                else { Add-Finding $row 'WARNING' "health alert $text" }
            }
            $bad = @($mine | Where-Object { "$($_.status)" -match 'RED|YELLOW|FAIL|ERROR' })
            if ($u.Kind -eq 'Firewall' -and $row.Health -and $row.Health -notmatch 'green' -and -not $bad.Count) {
                Add-Finding $row 'WARNING' "health status $($row.Health): $($u.Device.healthMessage)"
            }

            # disk and critical partitions, from the disk health module
            $disk = Get-DiskFromAlerts $mine
            if ($disk.Count) {
                $row.Disk = ($disk.Keys | ForEach-Object { "$_ $(Format-Pct $disk[$_])" }) -join ', '
                foreach ($k in $disk.Keys) {
                    if ($disk[$k] -ge $Settings.disk_fail_percent) { Add-Finding $row 'FAIL' "disk $k at $(Format-Pct $disk[$k])" }
                    elseif ($disk[$k] -ge $Settings.disk_warn_percent) { Add-Finding $row 'WARNING' "disk $k at $(Format-Pct $disk[$k])" }
                }
            }
            else { $row.Disk = 'no data' }

            # CPU and memory, latest and peak over the period
            foreach ($m in @(
                    @{ Name = 'cpu'; Regex = '.*_avg'; Field = 'Cpu'; Limit = $Settings.cpu_warn_percent; Label = 'CPU' },
                    @{ Name = 'mem'; Regex = 'used_percentage_.*'; Field = 'Memory'; Limit = $Settings.memory_warn_percent; Label = 'memory' })) {
                try {
                    $vals = Get-Metric $S $u.Id $m.Name $m.Regex $start $now
                    & $save "metric-$($m.Name)-$($u.Name)" $vals
                    if (-not $vals.Count) { $row[$m.Field] = 'no data'; continue }
                    $worstNow = ($vals.Values | ForEach-Object { $_.Latest } | Measure-Object -Maximum).Maximum
                    $peak = ($vals.Values | ForEach-Object { $_.Peak } | Measure-Object -Maximum).Maximum
                    $row[$m.Field] = "$(Format-Pct $worstNow) (peak $(Format-Pct $peak))"
                    if ($worstNow -ge $m.Limit) { Add-Finding $row 'WARNING' "$($m.Label) at $(Format-Pct $worstNow), above $($m.Limit)%" }
                }
                catch { $row[$m.Field] = 'not available' }
            }
            $rows += $row
        }

        # HA pairs: roles, expected active unit, config sync
        foreach ($p in $pairs) {
            $row = New-Row "$($p.name)" 'HA pair'
            $ps = $p.metadata.primaryStatus; $ss = $p.metadata.secondaryStatus
            $pn = "$($ps.device.name)"; $sn = "$($ss.device.name)"
            if (-not $pn) { $pn = "$($p.primary.name)" }
            if (-not $sn) { $sn = "$($p.secondary.name)" }
            $pst = "$($ps.currentStatus)"; $sst = "$($ss.currentStatus)"
            $row.Role = "$pn $pst / $sn $sst"
            $row.Health = "$($p.metadata.configStatus)"
            $active = if ($pst -match 'active') { $pn } elseif ($sst -match 'active') { $sn } else { '' }
            if (-not $active) { Add-Finding $row 'FAIL' 'no unit is Active' }
            elseif (-not (@($pst, $sst) -match 'standby')) { Add-Finding $row 'FAIL' "the other unit is not Standby ($pst / $sst)" }
            $want = $Settings.ha_expected_active["$($p.name)"]
            if ($want -and $active -and $active -ne $want) { Add-Finding $row 'WARNING' "failover happened: $active is Active, normally $want" }
            if ($row.Health -and $row.Health -notmatch 'HEALTHY') { Add-Finding $row 'WARNING' "config status $($row.Health)" }
            $rows += $row
        }
    }
    finally { Disconnect-Fmc $S }

    @{ Rows = $rows; Info = $info; Notes = $notes }
}

# ---------------------------------------------------------------- report

function Get-SafeHtml([string]$t) { [System.Net.WebUtility]::HtmlEncode($t) }

function New-ReportHtml($Settings, $Result, $Overall, $Stamp) {
    $date = Get-Date -Format 'MM/dd/yyyy'
    $problems = @($Result.Rows | Where-Object { $_.Result -ne 'PASS' })
    $comment = if ($Overall -eq 'PASS') {
        'Checks have been completed. There is nothing to report.'
    } else {
        (@($problems | ForEach-Object { "$($_.Unit): " + ((@($_.Findings | Where-Object { $_ -notlike 'ignored*' })) -join '; ') }) +
            @($Result.Notes | Where-Object { $_ -match '^(FAIL|WARNING)' })) -join '<br>'
    }
    if ($Overall -ne 'PASS') { $comment = ($comment -split '<br>' | ForEach-Object { Get-SafeHtml $_ }) -join '<br>' }
    $td = 'style="border:1px solid #999;padding:4px 8px;vertical-align:top"'
    $th = 'style="border:1px solid #999;padding:4px 8px;background:#1b2430;color:#fff;text-align:left"'
    $color = @{ PASS = '#dff0e4'; WARNING = '#faf0d2'; FAIL = '#f6dede' }

    $sb = New-Object Text.StringBuilder
    [void]$sb.Append('<div style="font-family:Segoe UI,Arial,sans-serif;font-size:10.5pt">')
    [void]$sb.Append('<p>Good Morning All,</p><p>Daily production checks have been completed, and the results are as follows.</p>')
    [void]$sb.Append("<table style=""border-collapse:collapse""><tr><th $th>Checklist</th><th $th>Steps</th><th $th>Assigned to</th><th $th>Completed</th><th $th>Comments</th></tr>")
    [void]$sb.Append("<tr><td $td>Check Firewall</td><td $td>Cisco FMC $(Get-SafeHtml $Settings.fmc): firewalls connected, health alerts, HA status, CPU, memory, disk and critical partitions (automated)</td>")
    [void]$sb.Append("<td $td>$(Get-SafeHtml $Settings.assigned_to)</td><td $td>$date</td><td style=""border:1px solid #999;padding:4px 8px;vertical-align:top;background:$($color[$Overall])"">$Overall<br>$comment</td></tr></table>")

    [void]$sb.Append('<p><b>Details</b></p>')
    [void]$sb.Append("<table style=""border-collapse:collapse""><tr>")
    foreach ($h in 'Unit', 'Type', 'Role', 'Connected', 'Health', 'Version', 'CPU', 'Memory', 'Disk', 'Result') { [void]$sb.Append("<th $th>$h</th>") }
    [void]$sb.Append('</tr>')
    foreach ($r in $Result.Rows) {
        [void]$sb.Append('<tr>')
        foreach ($v in $r.Unit, $r.Type, $r.Role, $r.Connected, $r.Health, $r.Version, $r.Cpu, $r.Memory, $r.Disk) { [void]$sb.Append("<td $td>$(Get-SafeHtml "$v")</td>") }
        [void]$sb.Append("<td style=""border:1px solid #999;padding:4px 8px;vertical-align:top;background:$($color[$r.Result])"">$($r.Result)</td></tr>")
        if ($r.Findings.Count) {
            [void]$sb.Append("<tr><td $td></td><td $td colspan=""9"">$((@($r.Findings | ForEach-Object { Get-SafeHtml $_ })) -join '<br>')</td></tr>")
        }
    }
    [void]$sb.Append('</table>')
    if ($Result.Notes.Count) { [void]$sb.Append('<p>' + ((@($Result.Notes | ForEach-Object { Get-SafeHtml $_ })) -join '<br>') + '</p>') }
    [void]$sb.Append('<p style="color:#555">Connection and intrusion events are not available through the FMC connection; review them in FMC (Analysis &gt; Connections / Intrusions) if anything above needs a closer look.</p>')
    if ($Settings.email -and $Settings.email.signature) {
        [void]$sb.Append('<p>' + ((("$($Settings.email.signature)") -split '\r?\n' | ForEach-Object { Get-SafeHtml $_ }) -join '<br>') + '</p>')
    }
    [void]$sb.Append("<p style=""color:#888;font-size:8.5pt"">Generated $Stamp by FirewallHealthCheck.ps1</p></div>")
    $sb.ToString()
}

function Send-Report($Settings, $Html, $Overall, [string[]]$Attachments) {
    $e = $Settings.email
    if (-not $e -or -not $e.enabled) { Write-Line 'Email: off in the settings file'; return }
    if ("$($e.send_when)" -eq 'problems' -and $Overall -eq 'PASS') { Write-Line 'Email: not sent, everything passed (send_when = problems)'; return }
    $to = @($e.to | Where-Object { $_ })
    if (-not $to.Count) { throw 'email "to" is empty' }
    if (-not "$($e.from)") { throw 'email "from" is empty' }

    $msg = New-Object System.Net.Mail.MailMessage
    $msg.From = New-Object System.Net.Mail.MailAddress("$($e.from)")
    foreach ($a in $to) { $msg.To.Add("$a") }
    foreach ($a in @($e.cc | Where-Object { $_ })) { $msg.CC.Add("$a") }
    $subject = if ($e.subject) { "$($e.subject)" } else { 'Daily Production Checks - Firewall {date}' }
    $subject = $subject.Replace('{date}', (Get-Date -Format 'M/d/yyyy')).Replace('{result}', $Overall)
    if ($Overall -ne 'PASS' -and $subject -notmatch [regex]::Escape($Overall)) { $subject = "[$Overall] $subject" }
    $msg.Subject = $subject
    $msg.Body = $Html
    $msg.IsBodyHtml = $true
    foreach ($f in $Attachments) { if ($f -and (Test-Path -LiteralPath $f)) { $msg.Attachments.Add((New-Object System.Net.Mail.Attachment($f))) } }

    $smtp = New-Object System.Net.Mail.SmtpClient
    if ($e.pickup_folder) {
        # testing: write the email as a file instead of sending it
        $dir = if ([IO.Path]::IsPathRooted("$($e.pickup_folder)")) { "$($e.pickup_folder)" } else { Join-Path $Root "$($e.pickup_folder)" }
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
        $smtp.DeliveryMethod = [System.Net.Mail.SmtpDeliveryMethod]::SpecifiedPickupDirectory
        $smtp.PickupDirectoryLocation = $dir
    }
    else {
        $smtp.Host = "$($e.smtp_server)"
        $smtp.Port = if ($e.port) { [int]$e.port } else { 25 }
        $smtp.EnableSsl = [bool]$e.use_ssl
        $smtp.Timeout = 60000
        if ($e.username) { $smtp.Credentials = New-Object System.Net.NetworkCredential("$($e.username)", "$env:SMTP_PASSWORD") }
        else { $smtp.UseDefaultCredentials = [bool]$e.use_windows_login }
    }
    try { $smtp.Send($msg) } finally { $msg.Dispose() }
    if ($e.pickup_folder) { Write-Line "Email: saved as a file in $($e.pickup_folder) (test mode)" }
    else { Write-Line "Email: sent to $($to -join ', ')" }
}

# ---------------------------------------------------------------- main

try { $settings = Read-Settings }
catch { Write-Line "Settings problem: $_"; exit 1 }

$pass = $env:FMC_PASSWORD
if (-not $pass) {
    if ($env:CI -or $env:GITLAB_CI -or -not [Environment]::UserInteractive) { Write-Line 'The FMC password is missing. Set the FMC_PASSWORD variable.'; exit 1 }
    $sec = Read-Host "FMC password for $($settings.username)" -AsSecureString
    $pass = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$reportDir = Join-Path $Root 'reports'
$rawDir = Join-Path $reportDir "firewall-raw-$stamp"
New-Item -ItemType Directory -Force -Path $rawDir | Out-Null

Write-Line "FIREWALL HEALTH CHECK  $stamp  (read only)"
$overall = 'PASS'
try {
    $result = Invoke-FirewallCheck $settings $pass $rawDir
    $levels = @($result.Rows | ForEach-Object { $_.Result }) + @($result.Notes | ForEach-Object { ($_ -split ':')[0] })
    if ($levels -contains 'FAIL') { $overall = 'FAIL' } elseif ($levels -contains 'WARNING') { $overall = 'WARNING' }
}
catch {
    Write-Line ''
    Write-Line "ERROR: $_"
    $result = @{ Rows = @(); Info = @{}; Notes = @("FAIL: the check could not run: $_") }
    $overall = 'FAIL'
}

Write-Line ''
foreach ($r in $result.Rows) {
    $bits = @()
    if ($r.Role) { $bits += $r.Role }
    if ($r.Cpu) { $bits += "CPU $($r.Cpu)" }
    if ($r.Memory) { $bits += "Mem $($r.Memory)" }
    if ($r.Disk) { $bits += "Disk $($r.Disk)" }
    Write-Line ('{0,-26} {1,-9} {2,-8} {3}' -f $r.Unit, $r.Type, $r.Result, ($bits -join '  '))
    foreach ($fnd in $r.Findings) { Write-Line "      $fnd" }
}
foreach ($n in $result.Notes) { Write-Line $n }
Write-Line ''
Write-Line "OVERALL: $overall"

$html = New-ReportHtml $settings $result $overall $stamp
$htmlPath = Join-Path $reportDir "firewall-$stamp.html"
$csvPath = Join-Path $reportDir "firewall-$stamp.csv"
Set-Content -Path $htmlPath -Value $html -Encoding UTF8
$result.Rows | ForEach-Object {
    [pscustomobject]@{ Unit = $_.Unit; Type = $_.Type; Role = $_.Role; Connected = $_.Connected; Health = $_.Health
        Version = $_.Version; Cpu = $_.Cpu; Memory = $_.Memory; Disk = $_.Disk; Result = $_.Result; Findings = ($_.Findings -join ' | ') }
} | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
Write-Line "Report saved: $htmlPath"

if (-not $NoEmail) {
    try { Send-Report $settings $html $overall @($csvPath) }
    catch { Write-Line "Email could NOT be sent: $_"; if ($overall -eq 'PASS') { $overall = 'WARNING' } }
}

if ($overall -eq 'FAIL') { exit 1 }
if ($overall -eq 'WARNING') { exit 2 }
exit 0
